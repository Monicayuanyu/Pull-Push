All the other code examples for the activities, hypertext concrete poem and the online portfolio can be found on the homework pages. 




